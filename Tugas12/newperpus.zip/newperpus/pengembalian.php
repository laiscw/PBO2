<?php
//Simpanlah dengan nama file : Pengembalian.php
require_once 'database.php';
class Pengembalian 
{
    private $db;
    private $table = 'pengembalian';
    public $Kode_Buku = "";
    public $Nama_Mahasiswa = "";
    public $Tanggal_Pinjam = "";
    public $Judul_Buku = "";
    public $Tahun_Terbit = "";
    public $Tanggal_Pengembalian = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_Kode_Buku(int $Kode_Buku)
    {
        $query = "SELECT * FROM $this->table WHERE Kode_Buku = $Kode_Buku";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`Kode_Buku`,`Nama_Mahasiswa`,`Tanggal_Pinjam`,`Judul_Buku`,`Tahun_Terbit`,`Tanggal_Pengembalian`) VALUES ('$this->Kode_Buku','$this->Nama_Mahasiswa','$this->Tanggal_Pinjam','$this->Judul_Buku','$this->Tahun_Terbit','$this->Tanggal_Pengembalian')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET Kode_Buku = '$this->Kode_Buku', Nama_Mahasiswa = '$this->Nama_Mahasiswa', Tanggal_Pinjam = '$this->Tanggal_Pinjam', Judul_Buku = '$this->Judul_Buku', Tahun_Terbit = '$this->Tahun_Terbit', Tanggal_Pengembalian = '$this->Tanggal_Pengembalian' 
        WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_Kode_Buku($Kode_Buku): int
    {
        $query = "UPDATE $this->table SET Kode_Buku = '$this->Kode_Buku', Nama_Mahasiswa = '$this->Nama_Mahasiswa', Tanggal_Pinjam = '$this->Tanggal_Pinjam', Judul_Buku = '$this->Judul_Buku', Tahun_Terbit = '$this->Tahun_Terbit', Tanggal_Pengembalian = '$this->Tanggal_Pengembalian' 
        WHERE Kode_Buku = $Kode_Buku";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE id = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_Kode_Buku($Kode_Buku): int
    {
        $query = "DELETE FROM $this->table WHERE Kode_Buku = $Kode_Buku";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>