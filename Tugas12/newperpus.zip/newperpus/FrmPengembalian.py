import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Pengembalian import *
class FrmPengembalian:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("800x500")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='KODE_BUKU:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='NAMA_MAHASISWA:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='TANGGAL_PINJAM:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='JUDUL_BUKU:').grid(row=3, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='TAHUN_TERBIT:').grid(row=4, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='TANGGAL_PENGEMBALIAN:').grid(row=5, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKode_Buku = Entry(mainFrame) 
        self.txtKode_Buku.grid(row=0, column=1, padx=5, pady=5)
        self.txtKode_Buku.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNama_Mahasiswa = Entry(mainFrame) 
        self.txtNama_Mahasiswa.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtTanggal_Pinjam = Entry(mainFrame) 
        self.txtTanggal_Pinjam.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtJudul_Buku = Entry(mainFrame) 
        self.txtJudul_Buku.grid(row=3, column=1, padx=5, pady=5)
        # Textbox
        self.txtTahun_Terbit = Entry(mainFrame) 
        self.txtTahun_Terbit.grid(row=4, column=1, padx=5, pady=5)
        # Textbox
        self.txtTanggal_Pengembalian = Entry(mainFrame) 
        self.txtTanggal_Pengembalian.grid(row=5, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('id','Kode_Buku','Nama_Mahasiswa','Tanggal_Pinjam','Judul_Buku','Tahun_Terbit','Tanggal_Pengembalian')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('id', text='ID')
        self.tree.column('id', width="30")
        self.tree.heading('Kode_Buku', text='KODE_BUKU')
        self.tree.column('Kode_Buku', width="100")
        self.tree.heading('Nama_Mahasiswa', text='NAMA_MAHASISWA')
        self.tree.column('Nama_Mahasiswa', width="125")
        self.tree.heading('Tanggal_Pinjam', text='TANGGAL_PINJAM')
        self.tree.column('Tanggal_Pinjam', width="125")
        self.tree.heading('Judul_Buku', text='JUDUL_BUKU')
        self.tree.column('Judul_Buku', width="150")
        self.tree.heading('Tahun_Terbit', text='TAHUN_TERBIT')
        self.tree.column('Tahun_Terbit', width="90")
        self.tree.heading('Tanggal_Pengembalian', text='TANGGAL_PENGEMBALIAN')
        self.tree.column('Tanggal_Pengembalian', width="155")
        # set tree position
        self.tree.place(x=0, y=230)
        
    def onClear(self, event=None):
        self.txtKode_Buku.delete(0,END)
        self.txtKode_Buku.insert(END,"")
        self.txtNama_Mahasiswa.delete(0,END)
        self.txtNama_Mahasiswa.insert(END,"")
        self.txtTanggal_Pinjam.delete(0,END)
        self.txtTanggal_Pinjam.insert(END,"")
        self.txtJudul_Buku.delete(0,END)
        self.txtJudul_Buku.insert(END,"")
        self.txtTahun_Terbit.delete(0,END)
        self.txtTahun_Terbit.insert(END,"")
        self.txtTanggal_Pengembalian.delete(0,END)
        self.txtTanggal_Pengembalian.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data pengembalian
        obj = Pengembalian()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["id"],d["Kode_Buku"],d["Nama_Mahasiswa"],d["Tanggal_Pinjam"],d["Judul_Buku"],d["Tahun_Terbit"],d["Tanggal_Pengembalian"]))
    def onCari(self, event=None):
        Kode_Buku = self.txtKode_Buku.get()
        obj = Pengembalian()
        a = obj.get_by_Kode_Buku(Kode_Buku)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        Kode_Buku = self.txtKode_Buku.get()
        obj = Pengembalian()
        res = obj.get_by_Kode_Buku(Kode_Buku)
        self.txtKode_Buku.delete(0,END)
        self.txtKode_Buku.insert(END,obj.Kode_Buku)
        self.txtNama_Mahasiswa.delete(0,END)
        self.txtNama_Mahasiswa.insert(END,obj.Nama_Mahasiswa)
        self.txtTanggal_Pinjam.delete(0,END)
        self.txtTanggal_Pinjam.insert(END,obj.Tanggal_Pinjam)
        self.txtJudul_Buku.delete(0,END)
        self.txtJudul_Buku.insert(END,obj.Judul_Buku)
        self.txtTahun_Terbit.delete(0,END)
        self.txtTahun_Terbit.insert(END,obj.Tahun_Terbit)
        self.txtTanggal_Pengembalian.delete(0,END)
        self.txtTanggal_Pengembalian.insert(END,obj.Tanggal_Pengembalian)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        Kode_Buku = self.txtKode_Buku.get()
        Nama_Mahasiswa = self.txtNama_Mahasiswa.get()
        Tanggal_Pinjam = self.txtTanggal_Pinjam.get()
        Judul_Buku = self.txtJudul_Buku.get()
        Tahun_Terbit = self.txtTahun_Terbit.get()
        Tanggal_Pengembalian = self.txtTanggal_Pengembalian.get()
        # create new Object
        obj = Pengembalian()
        obj.Kode_Buku = Kode_Buku
        obj.Nama_Mahasiswa = Nama_Mahasiswa
        obj.Tanggal_Pinjam = Tanggal_Pinjam
        obj.Judul_Buku = Judul_Buku
        obj.Tahun_Terbit = Tahun_Terbit
        obj.Tanggal_Pengembalian = Tanggal_Pengembalian
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_Kode_Buku(Kode_Buku)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        Kode_Buku = self.txtKode_Buku.get()
        obj = Pengembalian()
        obj.Kode_Buku = Kode_Buku
        if(self.ditemukan==True):
            res = obj.delete_by_Kode_Buku(Kode_Buku)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmPengembalian(root2, "Aplikasi Data Pengembalian")
    root2.mainloop()