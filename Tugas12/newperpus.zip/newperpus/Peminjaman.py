import requests
import json
class Peminjaman:
    def __init__(self):
        self.__id=None
        self.__Kode_Buku = None
        self.__Nama_Mahasiswa = None
        self.__Tanggal_Pinjam = None
        self.__Judul_Buku = None
        self.__Tahun_Terbit = None
        self.__url = "http://localhost/newperpus/peminjaman_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def Kode_Buku(self):
        return self.__Kode_Buku
        
    @Kode_Buku.setter
    def Kode_Buku(self, value):
        self.__Kode_Buku = value
    @property
    def Nama_Mahasiswa(self):
        return self.__Nama_Mahasiswa
        
    @Nama_Mahasiswa.setter
    def Nama_Mahasiswa(self, value):
        self.__Nama_Mahasiswa = value
    @property
    def Tanggal_Pinjam(self):
        return self.__Tanggal_Pinjam
        
    @Tanggal_Pinjam.setter
    def Tanggal_Pinjam(self, value):
        self.__Tanggal_Pinjam = value
    @property
    def Judul_Buku(self):
        return self.__Judul_Buku
        
    @Judul_Buku.setter
    def Judul_Buku(self, value):
        self.__Judul_Buku = value
    @property
    def Tahun_Terbit(self):
        return self.__Tahun_Terbit
        
    @Tahun_Terbit.setter
    def Tahun_Terbit(self, value):
        self.__Tahun_Terbit = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_Kode_Buku(self, Kode_Buku):
        url = self.__url+"?Kode_Buku="+Kode_Buku
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['id']
            self.__Kode_Buku = item['Kode_Buku']
            self.__Nama_Mahasiswa = item['Nama_Mahasiswa']
            self.__Tanggal_Pinjam = item['Tanggal_Pinjam']
            self.__Judul_Buku = item['Judul_Buku']
            self.__Tahun_Terbit = item['Tahun_Terbit']
        return data
    def simpan(self):
        payload = {
            "Kode_Buku":self.__Kode_Buku,
            "Nama_Mahasiswa":self.__Nama_Mahasiswa,
            "Tanggal_Pinjam":self.__Tanggal_Pinjam,
            "Judul_Buku":self.__Judul_Buku,
            "Tahun_Terbit":self.__Tahun_Terbit
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_Kode_Buku(self, Kode_Buku):
        url = self.__url+"?Kode_Buku="+Kode_Buku
        payload = {
            "Kode_Buku":self.__Kode_Buku,
            "Nama_Mahasiswa":self.__Nama_Mahasiswa,
            "Tanggal_Pinjam":self.__Tanggal_Pinjam,
            "Judul_Buku":self.__Judul_Buku,
            "Tahun_Terbit":self.__Tahun_Terbit
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_Kode_Buku(self,Kode_Buku):
        url = self.__url+"?Kode_Buku="+Kode_Buku
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text