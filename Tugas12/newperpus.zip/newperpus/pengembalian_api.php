<?php
require_once 'database.php';
require_once 'Pengembalian.php';
$db = new MySQLDatabase();
$pengembalian = new Pengembalian($db);
$id=0;
$Kode_Buku=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        if($id>0){    
            $result = $pengembalian->get_by_id($id);
        }elseif($Kode_Buku>0){
            $result = $pengembalian->get_by_Kode_Buku($Kode_Buku);
        } else {
            $result = $pengembalian->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new pengembalian
        $pengembalian->Kode_Buku = $_POST['Kode_Buku'];
        $pengembalian->Nama_Mahasiswa = $_POST['Nama_Mahasiswa'];
        $pengembalian->Tanggal_Pinjam = $_POST['Tanggal_Pinjam'];
        $pengembalian->Judul_Buku = $_POST['Judul_Buku'];
        $pengembalian->Tahun_Terbit = $_POST['Tahun_Terbit'];
        $pengembalian->Tanggal_Pengembalian = $_POST['Tanggal_Pengembalian'];
       
        $pengembalian->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pengembalian created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pengembalian not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $pengembalian->Kode_Buku = $_PUT['Kode_Buku'];
        $pengembalian->Nama_Mahasiswa = $_PUT['Nama_Mahasiswa'];
        $pengembalian->Tanggal_Pinjam = $_PUT['Tanggal_Pinjam'];
        $pengembalian->Judul_Buku = $_PUT['Judul_Buku'];
        $pengembalian->Tahun_Terbit = $_PUT['Tahun_Terbit'];
        $pengembalian->Tanggal_Pengembalian = $_PUT['Tanggal_Pengembalian'];
        if($id>0){    
            $pengembalian->update($id);
        }elseif($Kode_Buku<>""){
            $pengembalian->update_by_Kode_Buku($Kode_Buku);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pengembalian updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pengembalian update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        if($id>0){    
            $pengembalian->delete($id);
        }elseif($Kode_Buku>0){
            $pengembalian->delete_by_Kode_Buku($Kode_Buku);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Pengembalian deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Pengembalian delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>