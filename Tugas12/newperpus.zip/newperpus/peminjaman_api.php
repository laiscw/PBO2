<?php
require_once 'database.php';
require_once 'Peminjaman.php';
$db = new MySQLDatabase();
$peminjaman = new Peminjaman($db);
$id=0;
$Kode_Buku=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        if($id>0){    
            $result = $peminjaman->get_by_id($id);
        }elseif($Kode_Buku>0){
            $result = $peminjaman->get_by_Kode_Buku($Kode_Buku);
        } else {
            $result = $peminjaman->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new peminjaman
        $peminjaman->Kode_Buku = $_POST['Kode_Buku'];
        $peminjaman->Nama_Mahasiswa = $_POST['Nama_Mahasiswa'];
        $peminjaman->Tanggal_Pinjam = $_POST['Tanggal_Pinjam'];
        $peminjaman->Judul_Buku = $_POST['Judul_Buku'];
        $peminjaman->Tahun_Terbit = $_POST['Tahun_Terbit'];
       
        $peminjaman->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Peminjaman created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Peminjaman not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $peminjaman->Kode_Buku = $_PUT['Kode_Buku'];
        $peminjaman->Nama_Mahasiswa = $_PUT['Nama_Mahasiswa'];
        $peminjaman->Tanggal_Pinjam = $_PUT['Tanggal_Pinjam'];
        $peminjaman->Judul_Buku = $_PUT['Judul_Buku'];
        $peminjaman->Tahun_Terbit = $_PUT['Tahun_Terbit'];
        if($id>0){    
            $peminjaman->update($id);
        }elseif($Kode_Buku<>""){
            $peminjaman->update_by_Kode_Buku($Kode_Buku);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Peminjaman updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Peminjaman update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['Kode_Buku'])){
            $Kode_Buku = $_GET['Kode_Buku'];
        }
        if($id>0){    
            $peminjaman->delete($id);
        }elseif($Kode_Buku>0){
            $peminjaman->delete_by_Kode_Buku($Kode_Buku);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Peminjaman deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Peminjaman delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>